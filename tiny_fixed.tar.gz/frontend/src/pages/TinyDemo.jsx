import { useEffect, useState } from "react";

export default function TinyDemo() {
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    const host = window.location.hostname;

    let baseUrl = "";
    if (host.includes("-5173")) baseUrl = `https://${host.replace("-5173", "-4000")}`;
    else if (host.includes("localhost")) baseUrl = "http://localhost:4000";
    else baseUrl = `https://${host}`;

    fetch(`${baseUrl}/demo`)
      .then(r => {
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        return r.json();
      })
      .then(setData)
      .catch(e => setError(e.message));
  }, []);

  return (
    <div style={{ padding: 24 }}>
      <h1>Tiny Demo</h1>
      {error && <div style={{ color: "crimson" }}>Error: {error}</div>}
      <pre>{JSON.stringify(data, null, 2)}</pre>
    </div>
  );
}
